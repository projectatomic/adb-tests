#include<stdio.h>

int main()
{
    printf("Hello Data Dir");
    return 0;
}
